package com.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.StudentDTO;

public class MyBatisDAO {

	
    public List<StudentDTO> selectByEntranceDate(SqlSession session, HashMap map){
		
		List<StudentDTO> list = session.selectList("com.emp.Mppaer.selectByEntranceDate", map);
		
		return list;
	}


	
    public List<StudentDTO> selectByName(SqlSession session, String searchName){
		
		List<StudentDTO> list = session.selectList("com.emp.Mppaer.selectByName", searchName);
		
		return list;
	}


	public List<StudentDTO> selectAllStudent(SqlSession session){
		
		List<StudentDTO> list = session.selectList("com.emp.Mppaer.selectAllStudent");
		
		return list;
	}
}
