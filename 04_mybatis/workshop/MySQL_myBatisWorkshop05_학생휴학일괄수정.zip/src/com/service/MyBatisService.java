package com.service;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.StudentDTO;

public interface MyBatisService {

	public List<StudentDTO> selectAllStudent();
	public List<StudentDTO> selectByName(String searchName);
	public List<StudentDTO> selectByEntranceDate(HashMap map);
	public List<StudentDTO> selectBySearchNo(String searchNo);
	public int absenceChange(String searchNo);
}
