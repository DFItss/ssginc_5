package com.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.config.MySqlSessionFactory;
import com.dao.MyBatisDAO;
import com.dto.StudentDTO;

public class MyBatisServiceImpl implements MyBatisService{

	private MyBatisDAO dao;
	
	public MyBatisServiceImpl() {
	   dao = new MyBatisDAO();
	}
	
	public int absenceChange(String searchNo){
		
		String [] no = searchNo.split(",");
		ArrayList<String> k = new ArrayList<>();
		for(String x : no) {
			k.add(x);
		}
		int n = 0;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
		  n=dao.absenceChange(session, k);
		  session.commit();
		}finally {
			session.close();
		}
		return n;
	}
	
	public List<StudentDTO> selectBySearchNo(String searchNo){
	
		String [] no = searchNo.split(",");
		ArrayList<String> k = new ArrayList<>();
		for(String x : no) {
			k.add(x);
		}
		SqlSession session = MySqlSessionFactory.getSession();
		List<StudentDTO> list = null;
		try {
			list = dao.selectBySearchNo(session, k);
		}finally {
			session.close();
		}
		 return list;
	}
	
	

	 public List<StudentDTO> selectByEntranceDate(HashMap map){
			
			SqlSession session = MySqlSessionFactory.getSession();
			List<StudentDTO> list = null;
			try {
				list = dao.selectByEntranceDate(session,map);
			}finally {
				session.close();
			}
			 return list;
		}
	 
	 
    public List<StudentDTO> selectByName(String searchName){
		
		SqlSession session = MySqlSessionFactory.getSession();
		List<StudentDTO> list = null;
		try {
			list = dao.selectByName(session,searchName);
		}finally {
			session.close();
		}
		 return list;
	}
	public List<StudentDTO> selectAllStudent(){
		
		SqlSession session = MySqlSessionFactory.getSession();
		List<StudentDTO> list = null;
		try {
			list = dao.selectAllStudent(session);
		}finally {
			session.close();
		}
		 return list;
	}
}
