package com.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.StudentDTO;

public class MyBatisDAO {


	 public int absenceChange(SqlSession session, ArrayList<String> no){
			int n = session.update("com.emp.Mapper.absenceChange", no);
			return n;
	}
	
	 public List<StudentDTO> selectBySearchNo(SqlSession session, ArrayList<String> no){
			
			List<StudentDTO> list = session.selectList("com.emp.Mapper.selectBySearchNo", no);
			
			return list;
		}
	 
    public List<StudentDTO> selectByEntranceDate(SqlSession session, HashMap map){
		
		List<StudentDTO> list = session.selectList("com.emp.Mapper.selectByEntranceDate", map);
		
		return list;
	}


	
    public List<StudentDTO> selectByName(SqlSession session, String searchName){
		
		List<StudentDTO> list = session.selectList("com.emp.Mapper.selectByName", searchName);
		
		return list;
	}


	public List<StudentDTO> selectAllStudent(SqlSession session){
		
		List<StudentDTO> list = session.selectList("com.emp.Mapper.selectAllStudent");
		
		return list;
	}
}
