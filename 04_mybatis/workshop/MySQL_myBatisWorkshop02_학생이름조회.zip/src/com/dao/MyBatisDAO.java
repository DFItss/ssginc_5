package com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.StudentDTO;

public class MyBatisDAO {

	
    public List<StudentDTO> selectByName(SqlSession session, String searchName){
		
		List<StudentDTO> list = session.selectList("com.emp.Mapper.selectByName", searchName);
		
		return list;
	}


	public List<StudentDTO> selectAllStudent(SqlSession session){
		
		List<StudentDTO> list = session.selectList("com.emp.Mapper.selectAllStudent");
		
		return list;
	}
}
