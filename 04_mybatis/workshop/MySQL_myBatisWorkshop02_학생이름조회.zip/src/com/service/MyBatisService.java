package com.service;

import java.util.List;

import com.dto.StudentDTO;

public interface MyBatisService {

	public List<StudentDTO> selectAllStudent();
	public List<StudentDTO> selectByName(String searchName);
}
