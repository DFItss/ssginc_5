package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.config.MySqlSessionFactory;
import com.dao.MyBatisDAO;
import com.dto.StudentDTO;

public class MyBatisServiceImpl implements MyBatisService {

	private MyBatisDAO dao;
	
	public MyBatisServiceImpl() {
	   dao = new MyBatisDAO();
	}

    public List<StudentDTO> selectByName(String searchName){
		
		SqlSession session = MySqlSessionFactory.getSession();
		List<StudentDTO> list = null;
		try {
			list = dao.selectByName(session,searchName);
		}finally {
			session.close();
		}
		 return list;
	}
	public List<StudentDTO> selectAllStudent(){
		
		SqlSession session = MySqlSessionFactory.getSession();
		List<StudentDTO> list = null;
		try {
			list = dao.selectAllStudent(session);
		}finally {
			session.close();
		}
		 return list;
	}
}
