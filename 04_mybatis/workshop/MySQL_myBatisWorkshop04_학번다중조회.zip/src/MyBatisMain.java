import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.dto.StudentDTO;
import com.service.MyBatisServiceImpl;

public class MyBatisMain {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		while (true) {
			printMainMenu();
			String inputMenu = scan.next();
		    switch(inputMenu) {
		    
		    case "0": exit(); break;
		    case "1": printSelectAllStudent(); break;
		    case "2": {
		        System.out.print("검색할 학생명을 입력하시오 =>");
		        String searchName = scan.next();
		        printSearchName(searchName);
		     } break;
		    case "3": {
		        System.out.print("시작 입학년도 입력하시오 =>");
		        String startDate = scan.next();
		        System.out.print("끝 입학년도 입력하시오 =>");
		        String endDate = scan.next();
		        
		        printSearchEntranceDate(startDate,endDate);
		     }break;
		    case "4": {
		        System.out.print("검색할 학생의 학번을 입력하시오 =>"); //A674033,A656014,A213046
		        String searchNo = scan.next();
		        printSearchNo(searchNo);
		     }break;
		     
		    }
		} // end while

	}// end main

	private static void printSearchNo(String searchNo) {
		MyBatisServiceImpl service = new MyBatisServiceImpl();
		
		List<StudentDTO> list = service.selectBySearchNo(searchNo);
		System.out.println("====================================================================================");
		System.out.println("학번\t이름\t주민번호\t\t주소\t\t\t입학년도\t\t휴학여부");
		System.out.println("------------------------------------------------------------------------------------");
		for (StudentDTO dto : list) {
			System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\n",dto.getStuNo(),dto.getStuName(),dto.getStuSsn(),dto.getStuAddress(),dto.getEntDate(),dto.getAbsYn());
		}
	   System.out.printf("총 학생수: %d 명 \n" , list.size());
	}
	
	
	private static void printSearchEntranceDate(String startDate, String endDate) {
		MyBatisServiceImpl service = new MyBatisServiceImpl();
		HashMap map = new HashMap();
		map.put("startDate", startDate);
		map.put("endDate", endDate);
		
		List<StudentDTO> list = service.selectByEntranceDate(map);
		System.out.println("====================================================================================");
		System.out.println("학번\t이름\t주민번호\t\t주소\t\t\t입학년도\t\t휴학여부");
		System.out.println("------------------------------------------------------------------------------------");
		for (StudentDTO dto : list) {
			System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\n",dto.getStuNo(),dto.getStuName(),dto.getStuSsn(),dto.getStuAddress(),dto.getEntDate(),dto.getAbsYn());
		}
	   System.out.printf("총 학생수: %d 명 \n" , list.size());
	}
	
	
	
	
	
	
	private static void printSearchName(String searchName) {
		MyBatisServiceImpl service = new MyBatisServiceImpl();
		List<StudentDTO> list = service.selectByName(searchName);
		System.out.println("====================================================================================");
		System.out.println("학번\t이름\t주민번호\t\t주소\t\t\t입학년도\t\t휴학여부");
		System.out.println("------------------------------------------------------------------------------------");
		for (StudentDTO dto : list) {
			System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\n",dto.getStuNo(),dto.getStuName(),dto.getStuSsn(),dto.getStuAddress(),dto.getEntDate(),dto.getAbsYn());
		}
	   System.out.printf("총 학생수: %d 명 \n" , list.size());
	}
	
	
	private static void exit() {
		System.out.println("프로그램이 종료되었습니다.");
		System.exit(0);
	}
	
	private static void printSelectAllStudent(){
		
		MyBatisServiceImpl service = new MyBatisServiceImpl();
		List<StudentDTO> list = service.selectAllStudent();
		System.out.println("====================================================================================");
		System.out.println("학번\t이름\t주민번호\t\t주소\t\t\t입학년도\t\t휴학여부");
		System.out.println("------------------------------------------------------------------------------------");
		for (StudentDTO dto : list) {
			System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\n",dto.getStuNo(),dto.getStuName(),dto.getStuSsn(),dto.getStuAddress(),dto.getEntDate(),dto.getAbsYn());
		}
	   System.out.printf("총 학생수: %d 명 \n" , list.size());
	}
	
	
	private static void printMainMenu() {

		System.out.println("*****************************************");
		System.out.println("\t[학생 정보 관리 메뉴]");
		System.out.println("*****************************************");
		System.out.println("1.전체 학생 목록");
		System.out.println("2.학생 이름 검색");
		System.out.println("3.학생 입학년도 범위 검색 (예> 2000부터 2003년까지");
		System.out.println("4.학생 학번으로 다중 검색 (쉼표 구분자)");
		System.out.println("0.종료");
		System.out.println("*****************************************");
		System.out.print("메뉴 입력 => ");
	}//
	
	
	
	
}// end class
