
public class Test01 {
	public static void main(String[] args) {
		String s1 = "1";
		String s2 = "2";
		boolean bnx = false;
		char c1 = 'A';
		char c2 = 'B';
		char c3 = '1';
		char c4 = '2';
		int inx = 2;
		System.out.println("1" + "2");
		System.out.println(!bnx);
		System.out.println('A' + 'B');
		System.out.println('1' + 2);
		System.out.println('1' + '2');

		

		  
		}
}
