public class Test03 {
	public static void main(String[] args) {
		char ch = 'z';
		boolean b = 
		('a' <= ch && ch <= 'z') || ('A' <= ch && ch <= 'Z');
		System.out.println(b);
	}
}
