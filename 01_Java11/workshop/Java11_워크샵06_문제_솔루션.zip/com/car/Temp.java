package com.car;

public interface Temp {
	public int getTempGage();
}
